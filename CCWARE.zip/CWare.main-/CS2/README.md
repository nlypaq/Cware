# Cware for CS2
### Screenshot:
# Is it undetected?
### It's been undetected since it launched while using "Safe mode"
### Without "Safe mode" you could get banned. Use at your own risk!
# How it works?
### It's an external aplication that can read and write CS2 memory.
### Uses ImGui library to draw on the screen.
# Credits:
